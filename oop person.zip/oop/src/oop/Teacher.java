package oop;

public class Teacher extends Person {

    private String subject;

    public Teacher(String name, int age, String city, String subject) {
        super(name, age, city);
        this.subject = subject;
    }

    public String getSubject() {
        return subject;
    }

    @Override
    public void introduce() {
        System.out.println("Hello! I'm " + getName() + ", I teach " + subject);
    }

    @Override
    public void doWork() {
        System.out.println(getName() + " is teaching " + subject + " class.");
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Subject: " + subject);
        System.out.println();
    }

    // Overloading teach()
    public void teach() {
        System.out.println(getName() + " is teaching.");
    }

    public void teach(String topic) {
        System.out.println(getName() + " is teaching " + topic);
    }
}