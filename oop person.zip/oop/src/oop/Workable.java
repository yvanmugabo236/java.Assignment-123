package oop;

public interface Workable {
	void doWork();
}
